package com.prostaff.service.employee.aggregators;

import jakarta.persistence.Embeddable;

@Embeddable
public class BankDetail {

	String bankName;
	String ifscCode;
	String accountNumber;
	String branch;
}
