package com.prostaff.service.employee.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.prostaff.service.employee.dto.EmployeeDetailsUpdate;
import com.prostaff.service.employee.inter_service_communication.dto.EmployeeAdminEmailWrapper;
import com.prostaff.service.employee.inter_service_communication.dto.EmployeeBasicInformation;
import com.prostaff.service.employee.inter_service_communication.dto.EmployeeEmailWrapper;
import com.prostaff.service.employee.inter_service_communication.dto.EmployeeInformation;
import com.prostaff.service.employee.inter_service_communication.dto.EmployeeRegistrationDetail;
import com.prostaff.service.employee.repository.EmployeeRepo;
import com.prostaff.service.employee.service.EmployeeService;
import com.prostaff.service.employee.utils.EmailService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private EmailService emailService;

	@Override
	public Boolean addEmployee(EmployeeRegistrationDetail employeeRegistrationDetail) {
		
		
		
		// register with organization
		// add to auth table
		// create log
		
		emailService.sendWelcomeEmail("prajapativikram451@gmail.com", "Vikram Prajapati", "1234456rajnikandha");
		
		return true;
	}

	@Override
	public List<EmployeeBasicInformation> getemployeEmployeeBasicInformation(List<String> employeeEmails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeInformation getEmployeeInformation(EmployeeEmailWrapper employeeEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean updateEmployeeProfileImage(MultipartFile newImage, EmployeeEmailWrapper employeeEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteEmployee(EmployeeAdminEmailWrapper employeeAdminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean isEmployeeExist(EmployeeEmailWrapper employeeEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean updateEmployee(EmployeeDetailsUpdate employeeDetailsUpdate) {
		// TODO Auto-generated method stub
		return null;
	}

}
