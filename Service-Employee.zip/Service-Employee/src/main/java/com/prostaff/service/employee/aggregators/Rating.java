package com.prostaff.service.employee.aggregators;

import jakarta.persistence.Embeddable;

@Embeddable
public class Rating {

	Integer punctuality;
	Integer performance;
	Integer softSkills;
	Integer creativity;
}
